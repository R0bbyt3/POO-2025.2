package model.api.dto;

public enum PlayerColor {
    RED, BLUE, ORANGE, YELLOW, PURPLE, GRAY
}
